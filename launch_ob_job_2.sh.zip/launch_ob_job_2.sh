#!/bin/bash -l

#SBATCH --job-name="olfactory-bulb"
#SBATCH --ntasks-per-core=1
#SBATCH --ntasks-per-node=36
#SBATCH --cpus-per-task=1
#SBATCH --partition=debug
#SBATCH --constraint=mc
#SBATCH --mail-type=ALL
#SBATCH --account=ich002

mkdir logs

module swap PrgEnv-cray PrgEnv-intel
module load daint-mc cray-python/3.9.4.1 
module use /apps/hbp/ich002/hbp-spack-deployments/softwares/23-02-2022/modules/tcl/cray-cnl7-haswell
module load neuron/8.0.2

export PATH=/store/hbp/ich035/kumbhar/neuron_home/install3/bin:$PATH
export PYTHONPATH=/store/hbp/ich035/kumbhar/neuron_home/install3/lib/python/:$PYTHONPATH
export LANG=C
export LC_ALL=en_US


mkdir -p ./output2
cp -r /apps/hbp/ich002/cnr-software-utils/olfactory-bulb/olfactory-bulb-3d/ ./output2
cd ./output2/olfactory-bulb-3d/

git checkout 2to3

cd sim

rm -rf x86x64

nrnivmodl .

srun ./x86_64/special -python -mpi bulb3dtest.py

